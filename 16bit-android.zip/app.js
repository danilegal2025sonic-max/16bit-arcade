const fileInput = document.querySelector('#rom-file');
const chooseButton = document.querySelector('#choose-game');
const changeButton = document.querySelector('#change-game');
const mount = document.querySelector('#emulator-mount');
const placeholder = document.querySelector('#screen-placeholder');
const statusPill = document.querySelector('#status-pill');
const statusText = document.querySelector('#status-text');
const gameLabel = document.querySelector('#game-label');
const controlHint = document.querySelector('#control-hint');
const toast = document.querySelector('#toast');

let currentObjectUrl = null;
let toastTimer = null;
let activeLaunch = 0;

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('is-visible');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove('is-visible'), 3600);
}

function setStatus(label, mode = '') {
  statusText.textContent = label;
  statusPill.classList.remove('is-loading', 'is-playing', 'is-error');
  if (mode) statusPill.classList.add(`is-${mode}`);
}

function setGame(file) {
  const extension = file.name.split('.').pop().toLowerCase();
  const supported = ['md', 'gen', 'bin', 'smd', 'zip', 'rom'];

  if (!supported.includes(extension)) {
    showToast('Esse formato não parece ser uma ROM de Mega Drive.');
    fileInput.value = '';
    return;
  }

  const launchId = ++activeLaunch;
  if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);
  currentObjectUrl = URL.createObjectURL(file);
  const romUrl = currentObjectUrl;
  const safeRomUrl = JSON.stringify(romUrl).replace(/</g, '\\u003c');
  const safeGameName = JSON.stringify(file.name.replace(/\.[^.]+$/, '')).replace(/</g, '\\u003c');

  mount.replaceChildren();
  mount.hidden = false;
  placeholder.hidden = true;
  gameLabel.textContent = file.name.length > 24 ? `${file.name.slice(0, 21)}…` : file.name;
  controlHint.textContent = 'CARREGANDO JOGO';
  changeButton.hidden = false;
  chooseButton.querySelector('span:nth-child(2)').textContent = 'Escolher outro jogo';
  setStatus('CARREGANDO', 'loading');

  const iframe = document.createElement('iframe');
  iframe.className = 'emulator-frame';
  iframe.title = `Emulador — ${file.name}`;
  iframe.allow = 'autoplay; fullscreen; gamepad; pointer-lock';
  iframe.setAttribute('allowfullscreen', '');
  iframe.srcdoc = `<!doctype html>
    <html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
    <style>html,body,#game{width:100%;height:100%;margin:0;background:#000;overflow:hidden}body{touch-action:none}</style></head>
    <body><div id="game"></div><script>
      window.EJS_player = '#game';
      window.EJS_core = 'segaMD';
      window.EJS_gameUrl = ${safeRomUrl};
      window.EJS_gameName = ${safeGameName};
      window.EJS_pathtodata = 'https://cdn.emulatorjs.org/stable/data/';
      window.EJS_color = '#d0f25c';
      window.EJS_backgroundColor = '#000000';
      window.EJS_controlScheme = 'segaMD';
      window.EJS_language = 'pt-BR';
      window.EJS_startOnLoaded = false;
      window.EJS_ready = function () { parent.postMessage({ type: 'sixteenbit-emulator-ready', id: ${launchId} }, '*'); };
      window.EJS_onGameStart = function () { parent.postMessage({ type: 'sixteenbit-game-started', id: ${launchId} }, '*'); };
    <\/script><script src="https://cdn.emulatorjs.org/stable/data/loader.js" onerror="parent.postMessage({type:'sixteenbit-load-error',id:${launchId}}, '*')"><\/script></body></html>`;
  iframe.addEventListener('error', () => {
    setStatus('ERRO', 'error');
    controlHint.textContent = 'NÃO FOI POSSÍVEL CARREGAR';
    showToast('Não foi possível abrir o emulador. Confira sua conexão e tente novamente.');
  });
  mount.append(iframe);

  window.setTimeout(() => {
    if (activeLaunch === launchId && statusText.textContent === 'CARREGANDO') {
      controlHint.textContent = 'VERIFIQUE ROM E INTERNET';
      setStatus('ERRO AO CARREGAR', 'error');
      showToast('O emulador demorou para iniciar. Confira o arquivo e sua conexão.');
    }
  }, 45000);
  fileInput.value = '';
}

chooseButton.addEventListener('click', () => fileInput.click());
changeButton.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', (event) => {
  const [file] = event.target.files;
  if (file) setGame(file);
});

window.addEventListener('message', (event) => {
  const currentFrame = mount.querySelector('iframe');
  if (!currentFrame || event.source !== currentFrame.contentWindow || event.data?.id !== activeLaunch) return;

  if (event.data?.type === 'sixteenbit-emulator-ready') {
    setStatus('JOGO PRONTO', 'playing');
    controlHint.textContent = 'TOQUE EM PLAY PARA INICIAR';
  } else if (event.data?.type === 'sixteenbit-game-started') {
    setStatus('EM EXECUÇÃO', 'playing');
    controlHint.textContent = 'TECLADO, CONTROLE OU TOQUE';
  } else if (event.data?.type === 'sixteenbit-load-error') {
    setStatus('ERRO AO CARREGAR', 'error');
    controlHint.textContent = 'VERIFIQUE SUA CONEXÃO';
    showToast('Não foi possível baixar o núcleo do emulador. Confira sua conexão.');
  }
});

window.addEventListener('pagehide', () => {
  if (currentObjectUrl) URL.revokeObjectURL(currentObjectUrl);
});

if ('serviceWorker' in navigator && location.protocol.startsWith('http')) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}
