# 16-Bit

Primeira versão de um emulador de Mega Drive/Genesis para navegador, computador e celular. A interface é uma PWA responsiva; a emulação usa o core `segaMD` do EmulatorJS, que seleciona o Genesis Plus GX.

## Rodar localmente

É necessário servir os arquivos por HTTP para que o emulador e a instalação da PWA funcionem. Com Python 3:

```bash
python3 -m http.server 8000
```

Depois abra <http://localhost:8000>.

## Usar

1. Toque ou clique em **Escolher um jogo**.
2. Selecione uma ROM de Mega Drive/Genesis (`.md`, `.gen`, `.bin`, `.smd`, `.rom` ou `.zip`).
3. Use teclado, controle conectado ou os controles de toque exibidos pelo emulador em dispositivos móveis.

O arquivo selecionado é carregado localmente no navegador e não é enviado por este aplicativo. O núcleo do emulador é baixado do CDN oficial do EmulatorJS, então é necessária conexão com a internet na primeira inicialização.

Use arquivos de jogos que você tenha direito de utilizar. O projeto não inclui nem distribui ROMs ou BIOS.
